function interfaceCheck()
uci.cursor():foreach("mwan3","interface",
function(e)
local e=e[".name"]
interfaceNumber=interfaceNumber+1
local t=ut.trim(sys.exec("uci -p /var/state get network."..e..".metric"))
if t==""then
errorFound=1
errorNoMetricList=errorNoMetricList..e.." "
else
metricList=metricList..e.." "..t.."\n"
end
local a=tonumber(ut.trim(sys.exec("echo $(uci -p /var/state get mwan3."..e..".track_ip) | wc -w")))
if a>0 then
local t=tonumber(ut.trim(sys.exec("uci -p /var/state get mwan3."..e..".reliability")))
if t and t>a then
errorFound=1
errorReliabilityList=errorReliabilityList..e.." "
end
end
if ut.trim(sys.exec("uci -p /var/state get network."..e))=="interface"then
local t=ut.trim(sys.exec("uci -p /var/state get network."..e..".ifname"))
if t=="uci: Entry not found"or t==""then
errorFound=1
errorNetConfigList=errorNetConfigList..e.." "
errorRouteList=errorRouteList..e.." "
else
local t=ut.trim(sys.exec("route -n | awk '{if ($8 == \""..t.."\" && $1 == \"0.0.0.0\" && $3 == \"0.0.0.0\") print $1}'"))
if t==""then
errorFound=1
errorRouteList=errorRouteList..e.." "
end
end
else
errorFound=1
errorNetConfigList=errorNetConfigList..e.." "
errorRouteList=errorRouteList..e.." "
end
end
)
local e=sys.exec("echo '"..metricList.."' | awk '{print $2}' | uniq -d")
if e~=""then
errorFound=1
local t=""
for e in e:gmatch("[^\r\n]+")do
t=sys.exec("echo '"..metricList.."' | grep '"..e.."' | awk '{print $1}'")
errorDuplicateMetricList=errorDuplicateMetricList..t
end
errorDuplicateMetricList=sys.exec("echo '"..errorDuplicateMetricList.."' | tr '\n' ' '")
end
end
function interfaceWarnings()
local e=""
if interfaceNumber<=250 then
e="<strong>"..translatef("There are currently %d of 250 supported interfaces configured",interfaceNumber).."</strong>"
else
e="<font color=\"ff0000\"><strong>"..translatef("WARNING: %d interfaces are configured exceeding the maximum of 250!",interfaceNumber).."</strong></font>"
end
if errorReliabilityList~=" "then
e=e.."<br /><br /><font color=\"ff0000\"><strong>"..translate("WARNING: some interfaces have a higher reliability requirement than there are tracking IP addresses!").."</strong></font>"
end
if errorRouteList~=" "then
e=e.."<br /><br /><font color=\"ff0000\"><strong>"..translate("WARNING: some interfaces have no default route in the main routing table!").."</strong></font>"
end
if errorNetConfigList~=" "then
e=e.."<br /><br /><font color=\"ff0000\"><strong>"..translate("WARNING: some interfaces are configured incorrectly or not at all in /etc/config/network!").."</strong></font>"
end
if errorNoMetricList~=" "then
e=e.."<br /><br /><font color=\"ff0000\"><strong>"..translate("WARNING: some interfaces have no metric configured in /etc/config/network!").."</strong></font>"
end
if errorDuplicateMetricList~=" "then
e=e.."<br /><br /><font color=\"ff0000\"><strong>"..translate("WARNING: some interfaces have duplicate metrics configured in /etc/config/network!").."</strong></font>"
end
return e
end
dsp=require"luci.dispatcher"
sys=require"luci.sys"
ut=require"luci.util"
interfaceNumber=0
metricList=""
errorFound=0
errorDuplicateMetricList=" "
errorNetConfigList=" "
errorNoMetricList=" "
errorReliabilityList=" "
errorRouteList=" "
interfaceCheck()
m5=Map("mwan3",translate("MWAN Interface Configuration"),
interfaceWarnings())
m5:append(Template("mwan/config_css"))
mwan_interface=m5:section(TypedSection,"interface",translate("Interfaces"),
translate("MWAN supports up to 250 physical and/or logical interfaces<br />"..
"MWAN requires that all interfaces have a unique metric configured in /etc/config/network<br />"..
"Names must match the interface name found in /etc/config/network (see advanced tab)<br />"..
"Names may contain characters A-Z, a-z, 0-9, _ and no spaces<br />"..
"Interfaces may not share the same name as configured members, policies or rules"))
mwan_interface.addremove=true
mwan_interface.dynamic=false
mwan_interface.sectionhead=translate("Interface")
mwan_interface.sortable=false
mwan_interface.template="cbi/tblsection"
mwan_interface.extedit=dsp.build_url("admin","network","mwan","configuration","interface","%s")
function mwan_interface.create(t,e)
TypedSection.create(t,e)
m5.uci:save("mwan3")
luci.http.redirect(dsp.build_url("admin","network","mwan","configuration","interface",e))
end
enabled=mwan_interface:option(DummyValue,"enabled",translate("Enabled"))
enabled.rawhtml=true
function enabled.cfgvalue(t,e)
if t.map:get(e,"enabled")=="1"then
return"Yes"
else
return"No"
end
end
track_ip=mwan_interface:option(DummyValue,"track_ip",translate("Tracking IP"))
track_ip.rawhtml=true
function track_ip.cfgvalue(t,e)
tracked=t.map:get(e,"track_ip")
if tracked then
local e=""
for a,t in pairs(tracked)do
e=e..t.."<br />"
end
return e
else
return"&#8212;"
end
end
reliability=mwan_interface:option(DummyValue,"reliability",translate("Tracking reliability"))
reliability.rawhtml=true
function reliability.cfgvalue(e,t)
if tracked then
return e.map:get(t,"reliability")or"&#8212;"
else
return"&#8212;"
end
end
count=mwan_interface:option(DummyValue,"count",translate("Ping count"))
count.rawhtml=true
function count.cfgvalue(e,t)
if tracked then
return e.map:get(t,"count")or"&#8212;"
else
return"&#8212;"
end
end
timeout=mwan_interface:option(DummyValue,"timeout",translate("Ping timeout"))
timeout.rawhtml=true
function timeout.cfgvalue(t,e)
if tracked then
local e=t.map:get(e,"timeout")
if e then
return e.."s"
else
return"&#8212;"
end
else
return"&#8212;"
end
end
interval=mwan_interface:option(DummyValue,"interval",translate("Ping interval"))
interval.rawhtml=true
function interval.cfgvalue(e,t)
if tracked then
local e=e.map:get(t,"interval")
if e then
return e.."s"
else
return"&#8212;"
end
else
return"&#8212;"
end
end
down=mwan_interface:option(DummyValue,"down",translate("Interface down"))
down.rawhtml=true
function down.cfgvalue(t,e)
if tracked then
return t.map:get(e,"down")or"&#8212;"
else
return"&#8212;"
end
end
up=mwan_interface:option(DummyValue,"up",translate("Interface up"))
up.rawhtml=true
function up.cfgvalue(t,e)
if tracked then
return t.map:get(e,"up")or"&#8212;"
else
return"&#8212;"
end
end
metric=mwan_interface:option(DummyValue,"metric",translate("Metric"))
metric.rawhtml=true
function metric.cfgvalue(t,e)
local e=sys.exec("uci -p /var/state get network."..e..".metric")
if e~=""then
return e
else
return"&#8212;"
end
end
errors=mwan_interface:option(DummyValue,"errors",translate("Errors"))
errors.rawhtml=true
function errors.cfgvalue(e,a)
if errorFound==1 then
local e,t="",""
if string.find(errorReliabilityList," "..a.." ")then
e="Higher reliability requirement than there are tracking IP addresses"
t="&#10;&#10;"
end
if string.find(errorRouteList," "..a.." ")then
e=e..t.."No default route in the main routing table"
t="&#10;&#10;"
end
if string.find(errorNetConfigList," "..a.." ")then
e=e..t.."Configured incorrectly or not at all in /etc/config/network"
t="&#10;&#10;"
end
if string.find(errorNoMetricList," "..a.." ")then
e=e..t.."No metric configured in /etc/config/network"
t="&#10;&#10;"
end
if string.find(errorDuplicateMetricList," "..a.." ")then
e=e..t.."Duplicate metric configured in /etc/config/network"
end
if e==""then
return""
else
return"<span title=\""..e.."\"><img src=\"/luci-static/resources/cbi/reset.gif\" alt=\"error\"></img></span>"
end
else
return""
end
end
return m5
