ut=require"luci.util"
networkConfig="/etc/config/network"
m5=SimpleForm("networkconf",nil)
m5:append(Template("mwan/advanced_networkconfig"))
f=m5:section(SimpleSection,nil,
translate("This section allows you to modify the contents of /etc/config/network"))
t=f:option(TextValue,"lines")
t.rmempty=true
t.rows=20
function t.cfgvalue()
return nixio.fs.readfile(networkConfig)or""
end
function t.write(t,t,e)
return nixio.fs.writefile(networkConfig,"\n"..ut.trim(e:gsub("\r\n","\n")).."\n")
end
function f.handle(e,e,e)
return true
end
return m5
