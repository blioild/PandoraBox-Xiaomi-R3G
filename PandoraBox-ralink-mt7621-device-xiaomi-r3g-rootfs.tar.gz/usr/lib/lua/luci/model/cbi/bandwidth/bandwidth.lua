local a=require"luci.tools.webadmin"
local a=require"luci.ip"
m=Map("bandwidth",translate("PandoraBox bandwidth"),
translate("PandoraBox bandwidth can control ip bandwidth"))
s=m:section(TypedSection,"bandwidth",translate("Bandwidth"))
s.anonymous=true
e=s:option(Flag,"enabled",translate("Enable"))
e.rmempty=false
dl=s:option(Value,"download",translate("Download speed(kbit/s)"))
dl.datatype="and(uinteger,min(1))"
ul=s:option(Value,"upload",translate("Upload speed(kbit/s)"))
ul.datatype="and(uinteger,min(1))"
x=s:option(Flag,"packets_frist",translate("Packets frist"))
x.rmempty=false
p=s:option(Value,"packets_threshold",translate("Packets threshold(KByte)"))
p:depends({packets_frist="1"})
p.default="128"
reset_type=s:option(ListValue,"type",translate("Bandwidth reset type"))
reset_type:value("monthly",translate("monthly"))
reset_type:value("weekly",translate("weekly"))
reset_type:value("daily",translate("daily"))
reset_type:value("hourly",translate("hourly"))
reset_day=s:option(Value,"day",translate("day"))
reset_day.default="1"
reset_day:depends({type="monthly"})
reset_day:value("1",translate("1st"))
reset_day:value("2",translate("2nd"))
reset_day:value("3",translate("3rd"))
reset_day:value("4",translate("4th"))
reset_day:value("5",translate("5th"))
reset_day:value("6",translate("6th"))
reset_day:value("7",translate("7th"))
reset_day:value("8",translate("8th"))
reset_day:value("9",translate("9th"))
reset_day:value("10",translate("10th"))
reset_day:value("11",translate("11th"))
reset_day:value("12",translate("12th"))
reset_day:value("13",translate("13th"))
reset_day:value("14",translate("14th"))
reset_day:value("15",translate("15th"))
reset_day:value("16",translate("16th"))
reset_day:value("17",translate("19th"))
reset_day:value("18",translate("18th"))
reset_day:value("19",translate("19th"))
reset_day:value("20",translate("20th"))
reset_day:value("21",translate("21th"))
reset_day:value("22",translate("22th"))
reset_day:value("23",translate("23th"))
reset_day:value("24",translate("24th"))
reset_day:value("25",translate("25th"))
reset_day:value("26",translate("26th"))
reset_day:value("27",translate("27th"))
reset_day:value("28",translate("28th"))
reset_day:value("29",translate("29th"))
reset_day:value("30",translate("30th"))
reset_day:value("31",translate("31th"))
reset_week=s:option(Value,"week",translate("week"))
reset_week.default="1"
reset_week:depends({type="weekly"})
reset_week:value("0",translate("Sunday"))
reset_week:value("1",translate("Monday"))
reset_week:value("2",translate("Tuesday"))
reset_week:value("3",translate("Wednesday"))
reset_week:value("4",translate("Thursday"))
reset_week:value("5",translate("Friday"))
reset_week:value("6",translate("Saturday"))
reset_hour=s:option(Value,"hour",translate("hour"))
reset_hour:value("0",translate("00:00"))
reset_hour:value("1",translate("01:00"))
reset_hour:value("2",translate("02:00"))
reset_hour:value("3",translate("03:00"))
reset_hour:value("4",translate("04:00"))
reset_hour:value("5",translate("05:00"))
reset_hour:value("6",translate("06:00"))
reset_hour:value("7",translate("07:00"))
reset_hour:value("8",translate("08:00"))
reset_hour:value("9",translate("09:00"))
reset_hour:value("10",translate("10:00"))
reset_hour:value("11",translate("11:00"))
reset_hour:value("12",translate("12:00"))
reset_hour:value("13",translate("13:00"))
reset_hour:value("14",translate("14:00"))
reset_hour:value("15",translate("15:00"))
reset_hour:value("16",translate("16:00"))
reset_hour:value("17",translate("17:00"))
reset_hour:value("18",translate("18:00"))
reset_hour:value("19",translate("19:00"))
reset_hour:value("20",translate("20:00"))
reset_hour:value("21",translate("21:00"))
reset_hour:value("22",translate("22:00"))
reset_hour:value("23",translate("23:00"))
reset_hour:depends({type="monthly"})
reset_hour:depends({type="weekly"})
reset_hour:depends({type="daily"})
s=m:section(TypedSection,"client_ip",translate("Bandwidth IP Rules"))
s.template="cbi/tblsection"
s.anonymous=true
s.addremove=true
s.sortable=true
t=s:option(ListValue,"priority",translate("Priority"))
t:value("1",translate("priority"))
t:value("2",translate("express"))
t:value("3",translate("normal"))
t:value("4",translate("low"))
t.default="4"
ipaddr=s:option(Value,"ipaddr",translate("IP Address"))
ipaddr:value("",translate("none"))
ipaddr.rmempty=true
luci.sys.net.ipv4_hints(function(e,t)
ipaddr:value(e,"%s (%s)"%{e,t})
end)
ports=s:option(Value,"ports",translate("Ports priority"))
ports:value("80",translate("http"))
ports:value("443",translate("https"))
ports:value("21",translate("ftp"))
ports:value("22",translate("ssh"))
ports:value("53",translate("dns"))
ports:value("20,25,80,443,53",translate("Usually port"))
ports.default="53"
ports.rmempty=true
download_threshold=s:option(Value,"download_threshold",translate("download threshold(KByte)"))
download_threshold.default="1024"
upload_threshold=s:option(Value,"upload_threshold",translate("upload threshold(KByte)"))
upload_threshold.default="512"
download=s:option(Value,"download",translate("download(kbit/s)"))
download.default="1024"
upload=s:option(Value,"upload",translate("upload(kbit/s)"))
upload.default="256"
comment=s:option(Value,"comment",translate("Comment"))
s=m:section(TypedSection,"client_mac",translate("bandwidth MAC Rules"))
s.template="cbi/tblsection"
s.anonymous=true
s.addremove=true
s.sortable=true
t=s:option(ListValue,"priority",translate("Priority"))
t:value("1",translate("priority"))
t:value("2",translate("express"))
t:value("3",translate("normal"))
t:value("4",translate("low"))
t.default="4"
mac=s:option(Value,"macaddr",translate("MAC Address"))
mac.rmempty=true
a.neighbors({family=4},function(e)
if e.mac and e.dest then
mac:value(e.mac,"%s (%s)"%{e.mac,e.dest:string()})
end
end)
ports=s:option(Value,"ports",translate("Ports priority"))
ports:value("80",translate("http"))
ports:value("443",translate("https"))
ports:value("21",translate("ftp"))
ports:value("22",translate("ssh"))
ports:value("53",translate("dns"))
ports:value("20,25,80,443,53",translate("Usually port"))
ports.default="53"
ports.rmempty=true
download_threshold=s:option(Value,"download_threshold",translate("download threshold(KByte)"))
download_threshold.default="1024"
upload_threshold=s:option(Value,"upload_threshold",translate("upload threshold(KByte)"))
upload_threshold.default="512"
download=s:option(Value,"download",translate("download(kbit/s)"))
download.default="1024"
upload=s:option(Value,"upload",translate("upload(kbit/s)"))
upload.default="256"
comment=s:option(Value,"comment",translate("Comment"))
return m
