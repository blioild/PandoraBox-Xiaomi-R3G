local x=require"nixio"
local p=require"nixio.fs"
local u=require"luci.sys"
local r=require"luci.util"
local j=require"luci.http"
local b=require"luci.dispatcher"
local d=require"luci.tools.webadmin"
local h=require"luci.cbi.datatypes"
local y=require"luci.controller.ddns"
local e=require"luci.tools.ddns"
local t=arg[1]
local l="<font color='red'>"
local c="</font>"
local s="<strong>"
local n="</strong>"
local m=translate("IPv6 not supported").." - "..
translate("please select 'IPv4' address version")
local q=s..
l..
translate("IPv6 not supported")..
c..
"<br />"..translate("please select 'IPv4' address version")..
n
local v=s..
l..
translate("IPv6 not supported")..
c..
"<br />"..translate("please select 'IPv4' address version in").." "..
[[<a href="]]..
b.build_url("admin","services","ddns","detail",t)..
"?tab.dns."..t.."=basic"..
[[">]]..
translate("Basic Settings")..
[[</a>]]..
n
function err_tab_basic(e)
return translate("Basic Settings").." - "..e.title..": "
end
function err_tab_adv(e)
return translate("Advanced Settings").." - "..e.title..": "
end
function err_tab_timer(e)
return translate("Timer Settings").." - "..e.title..": "
end
local w={}
local o=io.open("/etc/ddns/services","r")
if o then
local t,e,a
repeat
t=o:read("*l")
e=t and t:match('^%s*".*')
e=e and e:gsub('"','')
a=e and r.split(e,"(%s+)",nil,true)
if a then w[a[1]]=a[2]end
until not t
o:close()
end
local g={}
local o=io.open("/etc/ddns/services_ipv6","r")
if o then
local a,e,t
repeat
a=o:read("*l")
e=a and a:match('^%s*".*')
e=e and e:gsub('"','')
t=e and r.split(e,"(%s+)",nil,true)
if t then g[t[1]]=t[2]end
until not a
o:close()
end
local function k()
local a
local o=usev6:formvalue(t)
local i=(o=="1")
and src6:formvalue(t)
or src4:formvalue(t)
local e=y.luci_helper..[[ -]]
if(o=="1")then e=e..[[6]]end
if i=="network"then
a=(o=="1")
and ipn6:formvalue(t)
or ipn4:formvalue(t)
e=e..[[n ]]..a
elseif i=="web"then
a=(o=="1")
and iurl6:formvalue(t)
or iurl4:formvalue(t)
e=e..[[u ]]..a
a=(pxy)and pxy:formvalue(t)or""
if(a and#a>0)then
e=e..[[ -p ]]..a
end
elseif i=="interface"then
e=e..[[i ]]..ipi:formvalue(t)
elseif i=="script"then
e=e..[[s ]]..ips:formvalue(t)
end
e=e..[[ -- get_local_ip]]
return(u.call(e)==0)
end
local function i(o,e)
local t
local a
local i
if o=="domain"then t,a='%[DOMAIN%]','%$domain'
elseif o=="username"then t,a='%[USERNAME%]','%$username'
elseif o=="password"then t,a='%[PASSWORD%]','%$password'
elseif o=="param_enc"then t,a='%[PARAMENC%]','%$param_enc'
elseif o=="param_opt"then t,a='%[PARAMOPT%]','%$param_opt'
else
error("undefined option")
return-1
end
local o=false
if e:find('http')then
o=(e:find(t))
else
if not e:find("/")then
e="/usr/lib/ddns/"..e
end
if not p.access(e)then return-1 end
local i=io.input(e)
if not i then return-1 end
for e in i:lines()do
repeat
if e:find('^#')then break end
o=(e:find(t)or e:find(a))
until true
if o then break end
end
i:close()
end
return(o and 1 or 0)
end
local function f(s,o)
local a=usev6:formvalue(t)or"0"
local r=svc4:formvalue(t)or"-"
local h=svc6:formvalue(t)or"-"
local e,n
if(a=="0"and r=="-")or
(a=="1"and h=="-")then
e=uurl:formvalue(t)or""
if(#e==0)then
e=ush:formvalue(t)or""
end
elseif(a=="0")then
e=w[r]or""
else
e=g[h]or""
end
if(#e==0)then return""end
n=i(s.option,e)
if n<1 then return""end
if not o or(#o==0)then
return nil,err_tab_basic(s)..translate("missing / required")
end
return o
end
local o=Map("ddns")
o.title=y.app_title_back()
o.description=y.app_description()
o.redirect=b.build_url("admin","services","ddns")
o.on_after_commit=function(a)
if a.changed then
local e=e.get_pid(t)
if e>0 then
local e=x.kill(e,1)
end
end
end
if o:formvalue("cbid.ddns.%s._switch"%t)then
local e
local a=o:formvalue("cbid.ddns.%s.use_ipv6"%t)or"0"
if a=="1"then
e=o:formvalue("cbid.ddns.%s.ipv6_service_name"%t)or""
else
e=o:formvalue("cbid.ddns.%s.ipv4_service_name"%t)or""
end
if a~=(o:get(t,"use_ipv6")or"0")then
o:set(t,"use_ipv6",a)
end
if e~="-"then
o:set(t,"service_name",e)
else
o:del(t,"service_name")
end
o.uci:save(o.config)
j.redirect(b.build_url("admin","services","ddns","detail",t))
return
end
local b=o.uci:get(o.config,"global","ddns_logdir")or"/var/log/ddns"
local a=o:section(NamedSection,t,"service",
translate("Details for")..([[: <strong>%s</strong>]]%t),
translate("Configure here the details for selected Dynamic DNS service."))
a.instance=t
a:tab("basic",translate("Basic Settings"),nil)
a:tab("advanced",translate("Advanced Settings"),nil)
a:tab("timer",translate("Timer Settings"),nil)
a:tab("logview",translate("Log File Viewer"),nil)
en=a:taboption("basic",Flag,"enabled",
translate("Enabled"),
translate("If this service section is disabled it could not be started.".."<br />"..
"Neither from LuCI interface nor from console"))
en.orientation="horizontal"
luh=a:taboption("basic",Value,"lookup_host",
translate("Lookup Hostname"),
translate("Hostname/FQDN to validate, if IP update happen or necessary"))
luh.rmempty=false
luh.placeholder="myhost.example.com"
function luh.validate(t,e)
if not e
or not(#e>0)
or not h.hostname(e)then
return nil,err_tab_basic(t)..translate("invalid FQDN / required - Sample")..": 'myhost.example.com'"
else
return r.trim(e)
end
end
function luh.parse(a,t,o)
e.value_parse(a,t,o)
end
usev6=a:taboption("basic",ListValue,"use_ipv6",
translate("IP address version"),
translate("Defines which IP address 'IPv4/IPv6' is send to the DDNS provider"))
usev6.widget="radio"
usev6.default="0"
usev6:value("0",translate("IPv4-Address"))
function usev6.cfgvalue(t,a)
local a=AbstractValue.cfgvalue(t,a)or"0"
if e.has_ipv6 or(a=="1"and not e.has_ipv6)then
t:value("1",translate("IPv6-Address"))
end
if a=="1"and not e.has_ipv6 then
t.description=q
end
return a
end
function usev6.validate(a,t)
if(t=="1"and e.has_ipv6)or t=="0"then
return t
end
return nil,err_tab_basic(a)..m
end
function usev6.parse(a,o,t)
e.value_parse(a,o,t)
end
svc4=a:taboption("basic",ListValue,"ipv4_service_name",
translate("DDNS Service provider").." [IPv4]")
svc4.default="-"
svc4:depends("use_ipv6","0")
function svc4.cfgvalue(a,t)
local e=e.read_value(a,t,"service_name")
if e and(#e>0)then
for t,a in r.kspairs(w)do
if e==t then return e end
end
end
return"-"
end
function svc4.validate(a,e)
if usev6:formvalue(t)~="1"then
return e
else
return""
end
end
function svc4.write(t,e,a)
if usev6:formvalue(e)~="1"then
t.map:del(e,t.option)
if a~="-"then
t.map:del(e,"update_url")
t.map:del(e,"update_script")
return t.map:set(e,"service_name",a)
else
return t.map:del(e,"service_name")
end
end
end
function svc4.parse(o,a,t)
e.value_parse(o,a,t)
end
svc6=a:taboption("basic",ListValue,"ipv6_service_name",
translate("DDNS Service provider").." [IPv6]")
svc6.default="-"
svc6:depends("use_ipv6","1")
if not e.has_ipv6 then
svc6.description=q
end
function svc6.cfgvalue(t,a)
local e=e.read_value(t,a,"service_name")
if e and(#e>0)then
for t,a in r.kspairs(w)do
if e==t then return e end
end
end
return"-"
end
function svc6.validate(o,a)
if usev6:formvalue(t)=="1"then
if e.has_ipv6 then return a end
return nil,err_tab_basic(o)..m
else
return""
end
end
function svc6.write(t,e,a)
if usev6:formvalue(e)=="1"then
t.map:del(e,t.option)
if a~="-"then
t.map:del(e,"update_url")
t.map:del(e,"update_script")
return t.map:set(e,"service_name",a)
else
return t.map:del(e,"service_name")
end
end
end
function svc6.parse(o,a,t)
e.value_parse(o,a,t)
end
svs=a:taboption("basic",Button,"_switch")
svs.title=translate("Really change DDNS provider?")
svs.inputtitle=translate("Change provider")
svs.inputstyle="apply"
uurl=a:taboption("basic",Value,"update_url",
translate("Custom update-URL"),
translate("Update URL to be used for updating your DDNS Provider.".."<br />"..
"Follow instructions you will find on their WEB page."))
function uurl.validate(a,o)
local i=ush:formvalue(t)
local n=usev6:formvalue(t)
if(n~="1"and svc4:formvalue(t)~="-")or
(n=="1"and svc6:formvalue(t)~="-")then
return""
elseif not o or(#o==0)then
if not i or(#i==0)then
return nil,err_tab_basic(a)..translate("missing / required")
else
return""
end
elseif(#i>0)then
return nil,err_tab_basic(a)..translate("either url or script could be set")
end
local e=e.parse_url(o)
if not e.scheme=="http"then
return nil,err_tab_basic(a)..translate("must start with 'http://'")
elseif not e.query then
return nil,err_tab_basic(a).."<QUERY> "..translate("missing / required")
elseif not e.host then
return nil,err_tab_basic(a).."<HOST> "..translate("missing / required")
elseif u.call([[nslookup ]]..e.host..[[ >/dev/null 2>&1]])~=0 then
return nil,err_tab_basic(a)..translate("can not resolve host: ")..e.host
end
return o
end
function uurl.parse(t,a,o)
e.value_parse(t,a,o)
end
ush=a:taboption("basic",Value,"update_script",
translate("Custom update-script"),
translate("Custom update script to be used for updating your DDNS Provider."))
function ush.validate(o,e)
local a=uurl:formvalue(t)
local i=usev6:formvalue(t)
if(i~="1"and svc4:formvalue(t)~="-")or
(i=="1"and svc6:formvalue(t)~="-")then
return""
elseif not e or(#e==0)then
if not a or(#a==0)then
return nil,err_tab_basic(o)..translate("missing / required")
else
return""
end
elseif(#a>0)then
return nil,err_tab_basic(o)..translate("either url or script could be set")
elseif not p.access(e)then
return nil,err_tab_basic(o)..translate("File not found")
end
return e
end
function ush.parse(o,a,t)
e.value_parse(o,a,t)
end
dom=a:taboption("basic",Value,"domain",
translate("Domain"),
translate("Replaces [DOMAIN] in Update-URL"))
dom.placeholder="myhost.example.com"
function dom.validate(t,e)
return f(t,e)
end
function dom.parse(t,a,o)
e.value_parse(t,a,o)
end
user=a:taboption("basic",Value,"username",
translate("Username"),
translate("Replaces [USERNAME] in Update-URL (URL-encoded)"))
function user.validate(t,e)
return f(t,e)
end
function user.parse(o,a,t)
e.value_parse(o,a,t)
end
pw=a:taboption("basic",Value,"password",
translate("Password"),
translate("Replaces [PASSWORD] in Update-URL (URL-encoded)"))
pw.password=true
function pw.validate(t,e)
return f(t,e)
end
function pw.parse(a,o,t)
e.value_parse(a,o,t)
end
pe=a:taboption("basic",Value,"param_enc",
translate("Optional Encoded Parameter"),
translate("Optional: Replaces [PARAMENC] in Update-URL (URL-encoded)"))
function pe.validate(t,e)
return f(t,e)
end
function pe.parse(o,t,a)
e.value_parse(o,t,a)
end
po=a:taboption("basic",Value,"param_opt",
translate("Optional Parameter"),
translate("Optional: Replaces [PARAMOPT] in Update-URL (NOT URL-encoded)"))
function po.validate(e,t)
return f(e,t)
end
function po.parse(o,t,a)
e.value_parse(o,t,a)
end
local f=svc4:cfgvalue(t)
if f~="-"then
svs:depends("ipv4_service_name","-")
ush:depends("ipv4_service_name","?")
uurl:depends("ipv4_service_name","?")
else
uurl:depends("ipv4_service_name","-")
ush:depends("ipv4_service_name","-")
dom:depends("ipv4_service_name","-")
user:depends("ipv4_service_name","-")
pw:depends("ipv4_service_name","-")
pe:depends("ipv4_service_name","-")
po:depends("ipv4_service_name","-")
end
for e,t in r.kspairs(w)do
svc4:value(e)
if f~=e then
svs:depends("ipv4_service_name",e)
else
dom:depends("ipv4_service_name",((i(dom.option,t)==1)and e or"?"))
user:depends("ipv4_service_name",((i(user.option,t)==1)and e or"?"))
pw:depends("ipv4_service_name",((i(pw.option,t)==1)and e or"?"))
pe:depends("ipv4_service_name",((i(pe.option,t)==1)and e or"?"))
po:depends("ipv4_service_name",((i(po.option,t)==1)and e or"?"))
end
end
svc4:value("-",translate("-- custom --"))
local f=svc6:cfgvalue(t)
if f~="-"then
svs:depends("ipv6_service_name","-")
uurl:depends("ipv6_service_name","?")
ush:depends("ipv6_service_name","?")
else
uurl:depends("ipv6_service_name","-")
ush:depends("ipv6_service_name","-")
dom:depends("ipv6_service_name","-")
user:depends("ipv6_service_name","-")
pw:depends("ipv6_service_name","-")
pe:depends("ipv6_service_name","-")
po:depends("ipv6_service_name","-")
end
for e,t in r.kspairs(g)do
svc6:value(e)
if f~=e then
svs:depends("ipv6_service_name",e)
else
dom:depends("ipv6_service_name",((i(dom.option,t)==1)and e or"?"))
user:depends("ipv6_service_name",((i(user.option,t)==1)and e or"?"))
pw:depends("ipv6_service_name",((i(pw.option,t)==1)and e or"?"))
pe:depends("ipv6_service_name",((i(pe.option,t)==1)and e or"?"))
po:depends("ipv6_service_name",((i(po.option,t)==1)and e or"?"))
end
end
svc6:value("-",translate("-- custom --"))
if e.has_ssl or((o:get(t,"use_https")or"0")=="1")then
https=a:taboption("basic",Flag,"use_https",
translate("Use HTTP Secure"))
https.orientation="horizontal"
function https.cfgvalue(t,a)
local a=AbstractValue.cfgvalue(t,a)
if not e.has_ssl and a=="1"then
t.description=s..l..
translate("HTTPS not supported")..c.."<br />"..
translate("please disable").." !"..n
else
t.description=translate("Enable secure communication with DDNS provider")
end
return a
end
function https.validate(a,t)
if(t=="1"and e.has_ssl)or t=="0"then return t end
return nil,err_tab_basic(a)..translate("HTTPS not supported").." !"
end
function https.write(e,t,a)
if a=="1"then
return e.map:set(t,e.option,a)
else
e.map:del(t,"cacert")
return e.map:del(t,e.option)
end
end
end
if e.has_ssl then
cert=a:taboption("basic",Value,"cacert",
translate("Path to CA-Certificate"),
translate("directory or path/file").."<br />"..
translate("or")..s.." IGNORE "..n..
translate("to run HTTPS without verification of server certificates (insecure)"))
cert:depends("use_https","1")
cert.placeholder="/etc/ssl/certs"
cert.forcewrite=true
function cert.validate(a,e)
if https:formvalue(t)~="1"then
return""
end
if e then
if h.directory(e)
or h.file(e)
or(e=="IGNORE")
or(#e==0)then
return e
end
end
return nil,err_tab_basic(a)..
translate("file or directory not found or not 'IGNORE'").." !"
end
function cert.parse(t,o,a)
e.value_parse(t,o,a)
end
end
src4=a:taboption("advanced",ListValue,"ipv4_source",
translate("IP address source").." [IPv4]",
translate("Defines the source to read systems IPv4-Address from, that will be send to the DDNS provider"))
src4:depends("use_ipv6","0")
src4.default="network"
src4:value("network",translate("Network"))
src4:value("web",translate("URL"))
src4:value("interface",translate("Interface"))
src4:value("script",translate("Script"))
function src4.cfgvalue(a,t)
return e.read_value(a,t,"ip_source")
end
function src4.validate(e,a)
if usev6:formvalue(t)=="1"then
return""
elseif not k()then
return nil,err_tab_adv(e)..
translate("can not detect local IP. Please select a different Source combination")
else
return a
end
end
function src4.write(t,e,a)
if usev6:formvalue(e)=="1"then
return true
elseif a=="network"then
t.map:del(e,"ip_url")
t.map:del(e,"ip_interface")
t.map:del(e,"ip_script")
elseif a=="web"then
t.map:del(e,"ip_network")
t.map:del(e,"ip_interface")
t.map:del(e,"ip_script")
elseif a=="interface"then
t.map:del(e,"ip_network")
t.map:del(e,"ip_url")
t.map:del(e,"ip_script")
elseif a=="script"then
t.map:del(e,"ip_network")
t.map:del(e,"ip_url")
t.map:del(e,"ip_interface")
end
t.map:del(e,t.option)
return t.map:set(e,"ip_source",a)
end
function src4.parse(o,a,t)
e.value_parse(o,a,t)
end
src6=a:taboption("advanced",ListValue,"ipv6_source",
translate("IP address source").." [IPv6]",
translate("Defines the source to read systems IPv6-Address from, that will be send to the DDNS provider"))
src6:depends("use_ipv6",1)
src6.default="network"
src6:value("network",translate("Network"))
src6:value("web",translate("URL"))
src6:value("interface",translate("Interface"))
src6:value("script",translate("Script"))
if not e.has_ipv6 then
src6.description=v
end
function src6.cfgvalue(t,a)
return e.read_value(t,a,"ip_source")
end
function src6.validate(a,o)
if usev6:formvalue(t)~="1"then
return""
elseif not e.has_ipv6 then
return nil,err_tab_adv(a)..m
elseif not k()then
return nil,err_tab_adv(a)..
translate("can not detect local IP. Please select a different Source combination")
else
return o
end
end
function src6.write(t,e,a)
if usev6:formvalue(e)~="1"then
return true
elseif a=="network"then
t.map:del(e,"ip_url")
t.map:del(e,"ip_interface")
t.map:del(e,"ip_script")
elseif a=="web"then
t.map:del(e,"ip_network")
t.map:del(e,"ip_interface")
t.map:del(e,"ip_script")
elseif a=="interface"then
t.map:del(e,"ip_network")
t.map:del(e,"ip_url")
t.map:del(e,"ip_script")
elseif a=="script"then
t.map:del(e,"ip_network")
t.map:del(e,"ip_url")
t.map:del(e,"ip_interface")
end
t.map:del(e,t.option)
return t.map:set(e,"ip_source",a)
end
function src6.parse(a,o,t)
e.value_parse(a,o,t)
end
ipn4=a:taboption("advanced",ListValue,"ipv4_network",
translate("Network").." [IPv4]",
translate("Defines the network to read systems IPv4-Address from"))
ipn4:depends("ipv4_source","network")
ipn4.default="wan"
d.cbi_add_networks(ipn4)
function ipn4.cfgvalue(a,t)
return e.read_value(a,t,"ip_network")
end
function ipn4.validate(a,e)
if usev6:formvalue(t)=="1"
or src4:formvalue(t)~="network"then
return""
else
return e
end
end
function ipn4.write(t,e,a)
if usev6:formvalue(e)=="1"
or src4:formvalue(e)~="network"then
return true
else
t.map:set(e,"interface",a)
t.map:del(e,t.option)
return t.map:set(e,"ip_network",a)
end
end
function ipn4.parse(a,o,t)
e.value_parse(a,o,t)
end
ipn6=a:taboption("advanced",ListValue,"ipv6_network",
translate("Network").." [IPv6]")
ipn6:depends("ipv6_source","network")
ipn6.default="wan6"
d.cbi_add_networks(ipn6)
if e.has_ipv6 then
ipn6.description=translate("Defines the network to read systems IPv6-Address from")
else
ipn6.description=v
end
function ipn6.cfgvalue(a,t)
return e.read_value(a,t,"ip_network")
end
function ipn6.validate(o,a)
if usev6:formvalue(t)~="1"
or src6:formvalue(t)~="network"then
return""
elseif e.has_ipv6 then
return a
else
return nil,err_tab_adv(o)..m
end
end
function ipn6.write(t,e,a)
if usev6:formvalue(e)~="1"
or src6:formvalue(e)~="network"then
return true
else
t.map:set(e,"interface",a)
t.map:del(e,t.option)
return t.map:set(e,"ip_network",a)
end
end
function ipn6.parse(o,a,t)
e.value_parse(o,a,t)
end
iurl4=a:taboption("advanced",Value,"ipv4_url",
translate("URL to detect").." [IPv4]",
translate("Defines the Web page to read systems IPv4-Address from"))
iurl4:depends("ipv4_source","web")
iurl4.default="http://checkip.dyndns.com"
function iurl4.cfgvalue(t,a)
return e.read_value(t,a,"ip_url")
end
function iurl4.validate(o,a)
if usev6:formvalue(t)=="1"
or src4:formvalue(t)~="web"then
return""
elseif not a or#a==0 then
return nil,err_tab_adv(o)..translate("missing / required")
end
local e=e.parse_url(a)
if not(e.scheme=="http"or e.scheme=="https")then
return nil,err_tab_adv(o)..translate("must start with 'http://'")
elseif not e.host then
return nil,err_tab_adv(o).."<HOST> "..translate("missing / required")
elseif u.call([[nslookup ]]..e.host..[[>/dev/null 2>&1]])~=0 then
return nil,err_tab_adv(o)..translate("can not resolve host: ")..e.host
else
return a
end
end
function iurl4.write(t,e,a)
if usev6:formvalue(e)=="1"
or src4:formvalue(e)~="web"then
return true
else
t.map:del(e,t.option)
return t.map:set(e,"ip_url",a)
end
end
function iurl4.parse(a,o,t)
e.value_parse(a,o,t)
end
iurl6=a:taboption("advanced",Value,"ipv6_url",
translate("URL to detect").." [IPv6]")
iurl6:depends("ipv6_source","web")
iurl6.default="http://checkipv6.dyndns.com"
if e.has_ipv6 then
iurl6.description=translate("Defines the Web page to read systems IPv6-Address from")
else
iurl6.description=v
end
function iurl6.cfgvalue(a,t)
return e.read_value(a,t,"ip_url")
end
function iurl6.validate(a,o)
if usev6:formvalue(t)~="1"
or src6:formvalue(t)~="web"then
return""
elseif not e.has_ipv6 then
return nil,err_tab_adv(a)..m
elseif not o or#o==0 then
return nil,err_tab_adv(a)..translate("missing / required")
end
local e=e.parse_url(o)
if not(e.scheme=="http"or e.scheme=="https")then
return nil,err_tab_adv(a)..translate("must start with 'http://'")
elseif not e.host then
return nil,err_tab_adv(a).."<HOST> "..translate("missing / required")
elseif u.call([[nslookup ]]..e.host..[[>/dev/null 2>&1]])~=0 then
return nil,err_tab_adv(a)..translate("can not resolve host: ")..e.host
else
return o
end
end
function iurl6.write(t,e,a)
if usev6:formvalue(e)~="1"
or src6:formvalue(e)~="web"then
return true
else
t.map:del(e,t.option)
return t.map:set(e,"ip_url",a)
end
end
function iurl6.parse(a,o,t)
e.value_parse(a,o,t)
end
ipi=a:taboption("advanced",ListValue,"ip_interface",
translate("Interface"),
translate("Defines the interface to read systems IP-Address from"))
ipi:depends("ipv4_source","interface")
ipi:depends("ipv6_source","interface")
for t,e in pairs(u.net.devices())do
net=d.iface_get_network(e)
if net and net~="loopback"then
ipi:value(e)
end
end
function ipi.validate(e,a)
local e=usev6:formvalue(t)
if(e~="1"and src4:formvalue(t)~="interface")
or(e=="1"and src6:formvalue(t)~="interface")then
return""
else
return a
end
end
function ipi.write(t,e,o)
local a=usev6:formvalue(e)
if(a~="1"and src4:formvalue(e)~="interface")
or(a=="1"and src6:formvalue(e)~="interface")then
return true
else
local a=d.iface_get_network(o)
t.map:set(e,"interface",a)
return t.map:set(e,t.option,o)
end
end
function ipi.parse(o,a,t)
e.value_parse(o,a,t)
end
ips=a:taboption("advanced",Value,"ip_script",
translate("Script"),
translate("User defined script to read systems IP-Address"))
ips:depends("ipv4_source","script")
ips:depends("ipv6_source","script")
ips.placeholder="/path/to/script.sh"
function ips.validate(i,e)
local o=usev6:formvalue(t)
local a
if e then a=r.split(e," ")end
if(o~="1"and src4:formvalue(t)~="script")
or(o=="1"and src6:formvalue(t)~="script")then
return""
elseif not e or not(#e>0)or not p.access(a[1],"x")then
return nil,err_tab_adv(i)..
translate("not found or not executable - Sample: '/path/to/script.sh'")
else
return e
end
end
function ips.write(t,e,o)
local a=usev6:formvalue(e)
if(a~="1"and src4:formvalue(e)~="script")
or(a=="1"and src6:formvalue(e)~="script")then
return true
else
return t.map:set(e,t.option,o)
end
end
function ips.parse(a,o,t)
e.value_parse(a,o,t)
end
eif4=a:taboption("advanced",ListValue,"ipv4_interface",
translate("Event Network").." [IPv4]",
translate("Network on which the ddns-updater scripts will be started"))
eif4:depends("ipv4_source","web")
eif4:depends("ipv4_source","script")
eif4.default="wan"
d.cbi_add_networks(eif4)
function eif4.cfgvalue(a,t)
return e.read_value(a,t,"interface")
end
function eif4.validate(e,a)
local e=src4:formvalue(t)or""
if usev6:formvalue(t)=="1"
or e=="network"
or e=="interface"then
return""
else
return a
end
end
function eif4.write(t,e,o)
local a=src4:formvalue(e)or""
if usev6:formvalue(e)=="1"
or a=="network"
or a=="interface"then
return true
else
t.map:del(e,t.option)
return t.map:set(e,"interface",o)
end
end
function eif4.parse(a,o,t)
e.value_parse(a,o,t)
end
eif6=a:taboption("advanced",ListValue,"ipv6_interface",
translate("Event Network").." [IPv6]")
eif6:depends("ipv6_source","web")
eif6:depends("ipv6_source","script")
eif6.default="wan6"
d.cbi_add_networks(eif6)
if not e.has_ipv6 then
eif6.description=v
else
eif6.description=translate("Network on which the ddns-updater scripts will be started")
end
function eif6.cfgvalue(a,t)
return e.read_value(a,t,"interface")
end
function eif6.validate(o,i)
local a=src6:formvalue(t)or""
if usev6:formvalue(t)~="1"
or a=="network"
or a=="interface"then
return""
elseif not e.has_ipv6 then
return nil,err_tab_adv(o)..m
else
return i
end
end
function eif6.write(t,e,o)
local a=src6:formvalue(e)or""
if usev6:formvalue(e)~="1"
or a=="network"
or a=="interface"then
return true
else
t.map:del(e,t.option)
return t.map:set(e,"interface",o)
end
end
function eif6.parse(o,t,a)
e.value_parse(o,t,a)
end
if e.has_bindnet or((o:get(t,"bind_network")or"")~="")then
bnet=a:taboption("advanced",ListValue,"bind_network",
translate("Bind Network"))
bnet:depends("ipv4_source","web")
bnet:depends("ipv6_source","web")
bnet.default=""
bnet:value("",translate("-- default --"))
d.cbi_add_networks(bnet)
function bnet.cfgvalue(t,a)
local a=AbstractValue.cfgvalue(t,a)
if not e.has_bindnet and a~=""then
t.description=s..l..
translate("Binding to a specific network not supported")..c.."<br />"..
translate("please set to 'default'").." !"..n
else
t.description=translate("OPTIONAL: Network to use for communication")..
"<br />"..translate("Casual users should not change this setting")
end
return a
end
function bnet.validate(a,t)
if((t~="")and e.has_bindnet)or(t=="")then return t end
return nil,err_tab_adv(a)..translate("Binding to a specific network not supported").." !"
end
function bnet.parse(t,a,o)
e.value_parse(t,a,o)
end
end
if e.has_forceip or((o:get(t,"force_ipversion")or"0")~="0")then
fipv=a:taboption("advanced",Flag,"force_ipversion",
translate("Force IP Version"))
fipv.orientation="horizontal"
function fipv.cfgvalue(t,a)
local a=AbstractValue.cfgvalue(t,a)
if not e.has_forceip and a~="0"then
t.description=s..l..
translate("Force IP Version not supported")..c.."<br />"..
translate("please disable").." !"..n
else
t.description=translate("OPTIONAL: Force the usage of pure IPv4/IPv6 only communication.")
end
return a
end
function fipv.validate(a,t)
if(t=="1"and e.has_forceip)or t=="0"then return t end
return nil,err_tab_adv(a)..translate("Force IP Version not supported")
end
end
if e.has_dnsserver or((o:get(t,"dns_server")or"")~="")then
dns=a:taboption("advanced",Value,"dns_server",
translate("DNS-Server"),
translate("OPTIONAL: Use non-default DNS-Server to detect 'Registered IP'.").."<br />"..
translate("Format: IP or FQDN"))
dns.placeholder="mydns.lan"
function dns.validate(a,o)
if not o or(#o==0)then
return""
elseif not e.has_dnsserver then
return nil,err_tab_adv(a)..translate("Specifying a DNS-Server is not supported")
elseif not h.host(o)then
return nil,err_tab_adv(a)..translate("use hostname, FQDN, IPv4- or IPv6-Address")
else
local i=usev6:formvalue(t)or"0"
local t=fipv:formvalue(t)or"0"
local e=y.luci_helper..[[ -]]
if(i==1)then e=e..[[6]]end
if(t==1)then e=e..[[f]]end
e=e..[[d ]]..o..[[ -- verify_dns]]
local e=u.call(e)
if e==0 then return o
elseif e==2 then return nil,err_tab_adv(a)..translate("nslookup can not resolve host")
elseif e==3 then return nil,err_tab_adv(a)..translate("nc (netcat) can not connect")
elseif e==4 then return nil,err_tab_adv(a)..translate("Forced IP Version don't matched")
else return nil,err_tab_adv(a)..translate("unspecific error")
end
end
end
function dns.parse(a,o,t)
e.value_parse(a,o,t)
end
end
if e.has_bindhost or((o:get(t,"force_dnstcp")or"0")~="0")then
tcp=a:taboption("advanced",Flag,"force_dnstcp",
translate("Force TCP on DNS"))
tcp.orientation="horizontal"
function tcp.cfgvalue(t,a)
local a=AbstractValue.cfgvalue(t,a)
if not e.has_bindhost and a~="0"then
t.description=s..l..
translate("DNS requests via TCP not supported")..c.."<br />"..
translate("please disable").." !"..n
else
t.description=translate("OPTIONAL: Force the use of TCP instead of default UDP on DNS requests.")
end
return a
end
function tcp.validate(a,t)
if(t=="1"and e.has_bindhost)or t=="0"then
return t
end
return nil,err_tab_adv(a)..translate("DNS requests via TCP not supported")
end
end
if e.has_proxy or((o:get(t,"proxy")or"")~="")then
pxy=a:taboption("advanced",Value,"proxy",
translate("PROXY-Server"))
pxy.placeholder="user:password@myproxy.lan:8080"
function pxy.cfgvalue(t,a)
local a=AbstractValue.cfgvalue(t,a)
if not e.has_proxy and a~=""then
t.description=s..l..
translate("PROXY-Server not supported")..c.."<br />"..
translate("please remove entry").."!"..n
else
t.description=translate("OPTIONAL: Proxy-Server for detection and updates.").."<br />"..
translate("Format")..": "..s.."[user:password@]proxyhost:port"..n.."<br />"..
translate("IPv6 address must be given in square brackets")..": "..
s.." [2001:db8::1]:8080"..n
end
return a
end
function pxy.validate(a,o)
if not o or(#o==0)then
return""
elseif e.has_proxy then
local i=usev6:formvalue(t)or"0"
local t=fipv:formvalue(t)or"0"
local e=CRTL.luci_helper..[[ -]]
if(i==1)then e=e..[[6]]end
if(t==1)then e=e..[[f]]end
e=e..[[p ]]..o..[[ -- verify_proxy]]
local e=u.call(e)
if e==0 then return o
elseif e==2 then return nil,err_tab_adv(a)..translate("nslookup can not resolve host")
elseif e==3 then return nil,err_tab_adv(a)..translate("nc (netcat) can not connect")
elseif e==4 then return nil,err_tab_adv(a)..translate("Forced IP Version don't matched")
elseif e==5 then return nil,err_tab_adv(a)..translate("proxy port missing")
else return nil,err_tab_adv(a)..translate("unspecific error")
end
else
return nil,err_tab_adv(a)..translate("PROXY-Server not supported")
end
end
function pxy.parse(a,o,t)
e.value_parse(a,o,t)
end
end
slog=a:taboption("advanced",ListValue,"use_syslog",
translate("Log to syslog"),
translate("Writes log messages to syslog. Critical Errors will always be written to syslog."))
slog.default="2"
slog:value("0",translate("No logging"))
slog:value("1",translate("Info"))
slog:value("2",translate("Notice"))
slog:value("3",translate("Warning"))
slog:value("4",translate("Error"))
function slog.parse(a,t,o)
e.value_parse(a,t,o)
end
logf=a:taboption("advanced",Flag,"use_logfile",
translate("Log to file"),
translate("Writes detailed messages to log file. File will be truncated automatically.").."<br />"..
translate("File")..[[: "]]..b..[[/]]..t..[[.log"]])
logf.orientation="horizontal"
logf.default="1"
ci=a:taboption("timer",Value,"check_interval",
translate("Check Interval"))
ci.template="ddns/detail_value"
ci.default="10"
function ci.validate(o,a)
if not h.uinteger(a)
or tonumber(a)<1 then
return nil,err_tab_timer(o)..translate("minimum value 5 minutes == 300 seconds")
end
local e=e.calc_seconds(a,cu:formvalue(t))
if e>=300 then
return a
else
return nil,err_tab_timer(o)..translate("minimum value 5 minutes == 300 seconds")
end
end
function ci.write(t,a,o)
local e=e.calc_seconds(o,cu:formvalue(a))
if e~=600 then
return t.map:set(a,t.option,o)
else
t.map:del(a,"check_unit")
return t.map:del(a,t.option)
end
end
function ci.parse(o,t,a)
e.value_parse(o,t,a)
end
cu=a:taboption("timer",ListValue,"check_unit","not displayed, but needed otherwise error",
translate("Interval to check for changed IP".."<br />"..
"Values below 5 minutes == 300 seconds are not supported"))
cu.template="ddns/detail_lvalue"
cu.default="minutes"
cu:value("seconds",translate("seconds"))
cu:value("minutes",translate("minutes"))
cu:value("hours",translate("hours"))
function cu.write(t,o,a)
local e=e.calc_seconds(ci:formvalue(o),a)
if e~=600 then
return t.map:set(o,t.option,a)
else
return true
end
end
function cu.parse(t,o,a)
e.value_parse(t,o,a)
end
fi=a:taboption("timer",Value,"force_interval",
translate("Force Interval"))
fi.template="ddns/detail_value"
fi.default="72"
function fi.validate(i,a)
if not h.uinteger(a)
or tonumber(a)<0 then
return nil,err_tab_timer(i)..translate("minimum value '0'")
end
local n=e.calc_seconds(a,fu:formvalue(t))
if n==0 then
return a
end
local o=ci:formvalue(t)
if not h.uinteger(o)then
return""
end
local e=e.calc_seconds(o,cu:formvalue(t))
if n>=e then
return a
end
return nil,err_tab_timer(i)..translate("must be greater or equal 'Check Interval'")
end
function fi.write(t,a,o)
local e=e.calc_seconds(o,fu:formvalue(a))
if e~=259200 then
return t.map:set(a,t.option,o)
else
t.map:del(a,"force_unit")
return t.map:del(a,t.option)
end
end
function fi.parse(o,t,a)
e.value_parse(o,t,a)
end
fu=a:taboption("timer",ListValue,"force_unit","not displayed, but needed otherwise error",
translate("Interval to force updates send to DDNS Provider".."<br />"..
"Setting this parameter to 0 will force the script to only run once".."<br />"..
"Values lower 'Check Interval' except '0' are not supported"))
fu.template="ddns/detail_lvalue"
fu.default="hours"
fu:value("minutes",translate("minutes"))
fu:value("hours",translate("hours"))
fu:value("days",translate("days"))
function fu.write(t,o,a)
local e=e.calc_seconds(fi:formvalue(o),a)
if e~=259200 and e~=0 then
return t.map:set(o,t.option,a)
else
return true
end
end
function fu.parse(o,t,a)
e.value_parse(o,t,a)
end
rc=a:taboption("timer",Value,"retry_count")
rc.title=translate("Error Retry Counter")
rc.description=translate("On Error the script will stop execution after given number of retrys")
.."<br />"
..translate("The default setting of '0' will retry infinite.")
rc.default="0"
function rc.validate(t,e)
if not h.uinteger(e)then
return nil,err_tab_timer(t)..translate("minimum value '0'")
else
return e
end
end
function rc.parse(o,a,t)
e.value_parse(o,a,t)
end
ri=a:taboption("timer",Value,"retry_interval",
translate("Error Retry Interval"))
ri.template="ddns/detail_value"
ri.default="60"
function ri.validate(t,e)
if not h.uinteger(e)
or tonumber(e)<1 then
return nil,err_tab_timer(t)..translate("minimum value '1'")
else
return e
end
end
function ri.write(t,a,o)
local e=e.calc_seconds(o,ru:formvalue(a))
if e~=60 then
return t.map:set(a,t.option,o)
else
t.map:del(a,"retry_unit")
return t.map:del(a,t.option)
end
end
function ri.parse(a,t,o)
e.value_parse(a,t,o)
end
ru=a:taboption("timer",ListValue,"retry_unit","not displayed, but needed otherwise error",
translate("On Error the script will retry the failed action after given time"))
ru.template="ddns/detail_lvalue"
ru.default="seconds"
ru:value("seconds",translate("seconds"))
ru:value("minutes",translate("minutes"))
function ru.write(o,a,t)
local e=e.calc_seconds(ri:formvalue(a),t)
if e~=60 then
return o.map:set(a,o.option,t)
else
return true
end
end
function ru.parse(t,a,o)
e.value_parse(t,a,o)
end
lv=a:taboption("logview",DummyValue,"_logview")
lv.template="ddns/detail_logview"
lv.inputtitle=translate("Read / Reread log file")
lv.rows=50
function lv.cfgvalue(t,e)
local e=b.."/"..e..".log"
if p.access(e)then
return e.."\n"..translate("Please press [Read] button")
end
return e.."\n"..translate("File not found or empty")
end
return o
