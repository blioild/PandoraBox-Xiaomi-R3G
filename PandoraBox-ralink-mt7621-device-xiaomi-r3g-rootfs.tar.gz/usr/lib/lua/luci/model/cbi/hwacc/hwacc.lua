local e=require"nixio.fs"
m=Map("hwacc",translate("Hardware Accelerate"),translate("Hardware Accelerate Info"))
s=m:section(TypedSection,"hwnat",translate("Hardware NAT"),translate("Hardware NAT tips"))
s.addremove=false
s.anonymous=true
s:option(Flag,"enabled",translate("Enable"),translate("use Hardware NAT"))
p=s:option(Flag,"tcp_offload",translate("tcp accelerate"),translate("Enable TCP accelerate"))
p:depends({enabled="1"})
p=s:option(Flag,"udp_offload",translate("udp accelerate"),translate("Enable UDP accelerate"))
p:depends({enabled="1"})
p=s:option(Flag,"ipv6_offload",translate("ipv6 accelerate"),translate("Enable IPv6 accelerate"))
p:depends({enabled="1"})
p=s:option(Flag,"wifi_offload",translate("wifi accelerate"),translate("Enable WiFi/USBNet accelerate"))
p:depends({enabled="1"})
s=m:section(TypedSection,"hwcrypto",translate("Hardware Cypto"),translate("Hardware Cypto tips"))
s.addremove=false
s.anonymous=true
s:option(Flag,"enabled",translate("Enable"),translate("use Hardware Cypto"))
return m
