local e=require"nixio.fs"
m=Map("optimizer",translate("Optimizer"),translate("Optimizer Info"))
s=m:section(TypedSection,"optimizer",translate("Optimizer"),translate("Optimizer tips"))
s.addremove=false
s.anonymous=true
s:option(Flag,"usb3_disable",translate("Disable USB3"),translate("Disable USB3 Support"))
s:option(Flag,"enable",translate("Enable"),translate("Enabled Optimizer"))
mode_list=s:option(ListValue,"mode",translate("Accelerate mode"),translate("default to nas"))
mode_list:value("nas",translate("NAS accelerate"))
mode_list:value("nat",translate("NAT accelerate"))
mode_list:value("wifi",translate("WiFi accelerate"))
mode_list:value("balance",translate("Balance all"))
mode_list:value("auto",translate("Auto balance"))
mode_list:depends({enable="1"})
return m
