local e=require"luci.sys"
local e=e.net:devices()
m=Map("arpbind",translate("IP/MAC Binding"),
translatef("ARP is used to convert a network address (e.g. an IPv4 address) to a physical address such as a MAC address.Here you can add some static ARP binding rules."))
s=m:section(TypedSection,"arpbind",translate("Rules"))
s.template="cbi/tblsection"
s.anonymous=true
s.addremove=true
h=s:option(Value,"ipaddr",translate("IP Address"))
h.datatype="ipaddr"
h.optional=false
luci.sys.net.ipv4_hints(function(e,t)
h:value(e,"%s (%s)"%{e,t})
end)
mac=s:option(Value,"macaddr",translate("MAC Address"))
mac.datatype="macaddr"
mac.optional=false
luci.ip.neighbors({family=4},function(e)
if e.mac and e.dest then
mac:value(e.mac,"%s (%s)"%{e.mac,e.dest:string()})
end
end)
arp_comments=s:option(Value,"comments",translate("Comments"))
arp_comments.rmempty=true
return m
