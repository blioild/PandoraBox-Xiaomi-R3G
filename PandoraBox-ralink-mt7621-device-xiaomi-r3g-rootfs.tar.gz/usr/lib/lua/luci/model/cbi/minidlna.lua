local a,t,e
a=Map("minidlna",translate("miniDLNA"),
translate("MiniDLNA is server software with the aim of being fully compliant with DLNA/UPnP-AV clients."))
a:section(SimpleSection).template="minidlna_status"
t=a:section(TypedSection,"minidlna","miniDLNA Settings")
t.addremove=false
t.anonymous=true
t:tab("general",translate("General Settings"))
t:tab("advanced",translate("Advanced Settings"))
e=t:taboption("general",Flag,"enabled",translate("Enable:"))
e.rmempty=false
function e.cfgvalue(e,t)
return luci.sys.init.enabled("minidlna")and e.enabled or e.disabled
end
function e.write(o,a,t)
if t=="1"then
luci.sys.init.enable("minidlna")
luci.sys.call("/etc/init.d/minidlna start >/dev/null")
else
luci.sys.call("/etc/init.d/minidlna stop >/dev/null")
luci.sys.init.disable("minidlna")
end
return Flag.write(o,a,t)
end
e=t:taboption("general",Value,"port",translate("Port:"),
translate("Port for HTTP (descriptions, SOAP, media transfer) traffic."))
e.datatype="port"
e.default=8200
e=t:taboption("general",Value,"interface",translate("Interfaces:"),
translate("Network interfaces to serve."))
e.template="cbi/network_ifacelist"
e.widget="checkbox"
e.nocreate=true
function e.cfgvalue(t,a)
local e={}
local t=Value.cfgvalue(t,a)
if t then
local a
for t in t:gmatch("[^,%s]+")do
e[#e+1]=t
end
end
return e
end
function e.write(i,a,o)
local t={}
local n
for e in luci.util.imatch(o)do
t[#t+1]=e
end
Value.write(i,a,table.concat(t,","))
end
e=t:taboption("general",Value,"friendly_name",translate("Friendly name:"),
translate("Set this if you want to customize the name that shows up on your clients."))
e.rmempty=true
e.placeholder="OpenWrt DLNA Server"
e=t:taboption("advanced",Value,"db_dir",translate("Database directory:"),
translate("Set this if you would like to specify the directory where you want MiniDLNA to store its database and album art cache."))
e.rmempty=true
e.placeholder="/var/cache/minidlna"
e=t:taboption("advanced",Value,"log_dir",translate("Log directory:"),
translate("Set this if you would like to specify the directory where you want MiniDLNA to store its log file."))
e.rmempty=true
e.placeholder="/var/log"
t:taboption("advanced",Flag,"inotify",translate("Enable inotify:"),
translate("Set this to enable inotify monitoring to automatically discover new files."))
t:taboption("advanced",Flag,"enable_tivo",translate("Enable TIVO:"),
translate("Set this to enable support for streaming .jpg and .mp3 files to a TiVo supporting HMO."))
e.rmempty=true
e=t:taboption("advanced",Flag,"strict_dlna",translate("Strict to DLNA standard:"),
translate("Set this to strictly adhere to DLNA standards. This will allow server-side downscaling of very large JPEG images, which may hurt JPEG serving performance on (at least) Sony DLNA products."))
e.rmempty=true
e=t:taboption("advanced",Value,"presentation_url",translate("Presentation URL:"))
e.rmempty=true
e.placeholder="http://192.168.1.1/"
e=t:taboption("advanced",Value,"notify_interval",translate("Notify interval:"),
translate("Notify interval in seconds."))
e.datatype="uinteger"
e.placeholder=900
e=t:taboption("advanced",Value,"serial",translate("Announced serial number:"),
translate("Serial number the miniDLNA daemon will report to clients in its XML description."))
e.placeholder="12345678"
t:taboption("advanced",Value,"model_number",translate("Announced model number:"),
translate("Model number the miniDLNA daemon will report to clients in its XML description."))
e.placholder="1"
e=t:taboption("advanced",Value,"minissdpsocket",translate("miniSSDP socket:"),
translate("Specify the path to the MiniSSDPd socket."))
e.rmempty=true
e.placeholder="/var/run/minissdpd.sock"
e=t:taboption("general",ListValue,"root_container",translate("Root container:"))
e:value(".",translate("Standard container"))
e:value("B",translate("Browse directory"))
e:value("M",translate("Music"))
e:value("V",translate("Video"))
e:value("P",translate("Pictures"))
t:taboption("general",DynamicList,"media_dir",translate("Media directories:"),
translate("Set this to the directory you want scanned. If you want to restrict the directory to a specific content type, you can prepend the type ('A' for audio, 'V' for video, 'P' for images), followed by a comma, to the directory (eg. media_dir=A,/mnt/media/Music). Multiple directories can be specified."))
e=t:taboption("general",DynamicList,"album_art_names",translate("Album art names:"),
translate("This is a list of file names to check for when searching for album art."))
e.rmempty=true
e.placeholder="Cover.jpg"
function e.cfgvalue(e,a)
local t={}
local e=Value.cfgvalue(e,a)
if type(e)=="table"then
e=table.concat(e,"/")
elseif not e then
e=""
end
local a
for e in e:gmatch("[^/%s]+")do
t[#t+1]=e
end
return t
end
function e.write(o,a,t)
local e={}
local i
for t in luci.util.imatch(t)do
e[#e+1]=t
end
Value.write(o,a,table.concat(e,"/"))
end
return a
