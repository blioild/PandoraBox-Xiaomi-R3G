module("luci.controller.transmission",package.seeall)
function index()
if not nixio.fs.access("/etc/config/transmission")then
return
end
local e=entry({"admin","services","transmission"},cbi("transmission"),_("Transmission"))
e.dependent=true
end
