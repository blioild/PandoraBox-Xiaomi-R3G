module("luci.controller.upnp",package.seeall)
function index()
if not nixio.fs.access("/etc/config/upnpd")then
return
end
local e
e=entry({"admin","services","upnp"},cbi("upnp/upnp"),_("UPnP"))
e.dependent=true
entry({"admin","services","upnp","status"},call("act_status")).leaf=true
entry({"admin","services","upnp","delete"},post("act_delete")).leaf=true
end
function act_status()
local i=io.popen("iptables --line-numbers -t nat -xnvL MINIUPNPD 2>/dev/null")
if i then
local o={}
while true do
local e=i:read("*l")
if not e then
break
elseif e:match("^%d+")then
local a,i,t,n,e=
e:match("^(%d+).-([a-z]+).-dpt:(%d+) to:(%S-):(%d+)")
if a and i and t and n and e then
a=tonumber(a)
t=tonumber(t)
e=tonumber(e)
o[#o+1]={
num=a,
proto=i:upper(),
extport=t,
intaddr=n,
intport=e
}
end
end
end
i:close()
luci.http.prepare_content("application/json")
luci.http.write_json(o)
end
end
function act_delete(e)
local e=tonumber(e)
local t=luci.model.uci.cursor()
if e and e>0 then
luci.sys.call("iptables -t filter -D MINIUPNPD %d 2>/dev/null"%e)
luci.sys.call("iptables -t nat -D MINIUPNPD %d 2>/dev/null"%e)
local t=t:get("upnpd","config","upnp_lease_file")
if t and nixio.fs.access(t)then
luci.sys.call("sed -i -e '%dd' %q"%{e,t})
end
luci.http.status(200,"OK")
return
end
luci.http.status(400,"Bad request")
end
