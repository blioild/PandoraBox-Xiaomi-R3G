module("luci.controller.vsftpd",package.seeall)
function index()
require("luci.i18n")
luci.i18n.loadc("vsftpd")
if not nixio.fs.access("/etc/config/vsftpd")then
return
end
local e=entry({"admin","services","vsftpd"},cbi("vsftpd"),_("FTP Service"))
e.i18n="vsftpd"
e.dependent=true
end
