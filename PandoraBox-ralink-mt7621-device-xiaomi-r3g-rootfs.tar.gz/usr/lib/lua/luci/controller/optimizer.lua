module("luci.controller.optimizer",package.seeall)
function index()
if not nixio.fs.access("/etc/config/optimizer")then
return
end
local e
e=entry({"admin","network","optimizer"},cbi("optimizer/optimizer"),_("Optimizer"))
e.dependent=true
end
