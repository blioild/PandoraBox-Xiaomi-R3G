module("luci.controller.filemanager", package.seeall)

function index()
	if not nixio.fs.access("/etc/config/filemanager") then
		return
	end
	local page
	page = entry({"admin", "services", "filemanager"}, cbi("filemanager"), _("filemanager"), 100)
	page.i18n = "filemanager"
	page.dependent = true
end
