module("luci.controller.bandwidth", package.seeall)

function index()
	entry({"admin", "status", "ipbandwidth"}, template("admin_status/ipbandwidth"), _("ipbandwidth"), 9)
	entry({"admin", "status", "ipbandwidth_stat"}, call("action_stat"), nil, 6).leaf = true
	entry({"admin", "status", "ipbandwidth_ptr"}, call("action_ptr"), nil, 6).leaf = true
	if nixio.fs.access("/etc/config/bandwidth") then
		entry({"admin", "network", "bandwidth"}, cbi("bandwidth/bandwidth"), _("Bandwidth")).dependent = true
	end
end

function action_stat()
	require "luci.sys"
	require "luci.tools.webadmin"
	require "nixio.fs"
	local util = require "luci.util"

	local style = true

	local bwc = io.popen("cat /proc/bandwidth | sed 's/,/ /g' 2>/dev/null")
	local rv = {}
	if bwc then
		while true do
			local ln = bwc:read("*l")
			if not ln then break end
			local valist = util.split(ln, " ")
			local obj = {}
			obj.ip = valist[1]
			obj.mac = valist[2]
			obj.down = valist[3]
			obj.up = valist[4]
			obj.limited = valist[5]
			rv[#rv+1] = obj
		end
	end

	local data = rv
	rv = {}
	rv.date = os.time()
	rv.data = data
	luci.http.prepare_content("application/json")
	luci.http.write_json(rv)
	return
end

function action_ptr(...)
	local http = require "luci.http"
	local util = require "luci.util"

	http.prepare_content("application/json")
	http.write_json(util.ubus("network.rrdns", "lookup", {
		addrs = {...}, timeout = 3000
	}))
end