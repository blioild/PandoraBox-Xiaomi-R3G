module("luci.controller.update",package.seeall)
function index()
local e
e=entry({"admin","status","update"},template("ota/update"),_("Firmware Update"))
e=entry({"admin","status","get_ver"},call("action_get_ver"))
e=entry({"admin","status","get_change"},call("action_get_change"))
e.dependent=true
end
function read_log()
local e=io.open("/tmp/change.file","r")
if e~=nil then
ret=e:read("*all")
e:close()
else
ret=luci.i18n.translate("No Change Log Found")
end
return ret
end
function action_get_ver()
local e={}
local a
local t=io.open("/etc/openwrt_version","r")
if t~=nil then
a=t:read("*all")
t:close()
else
a=luci.i18n.translate("Unknow Version")
end
e["current"]=a
e["last"]=luci.model.uci.cursor():get("system","Version","last")
if e["last"]==nil then
e["last"]=luci.i18n.translate("Not Checked")
end
e["log"]=read_log()
e["status"]=" "
luci.http.prepare_content("application/json")
luci.http.write_json(e)
end
function action_get_change()
local e={}
local o=os.execute("/usr/bin/getlog.sh")
local t
local a=io.open("/etc/openwrt_version","r")
if a~=nil then
t=a:read("*all")
a:close()
else
t=luci.i18n.translate("Unknow Version")
end
e["current"]=t
e["last"]=luci.model.uci.cursor():get("system","Version","last")
if e["last"]==nil then
e["last"]=luci.i18n.translate("Not Checked")
end
e["log"]=read_log()
if o==0 then
e["status"]=" "
else
e["status"]=luci.i18n.translate("An Error occured while fetching the Change Log")
end
luci.http.prepare_content("application/json")
luci.http.write_json(e)
end
