module("luci.controller.uhttpd.uhttpd",package.seeall)
function index()
if not nixio.fs.access("/etc/config/uhttpd")then
return
end
local e
e=entry({"admin","services","uhttpd"},cbi("uhttpd/uhttpd"),_("uHTTPd"))
e.leaf=true
end
