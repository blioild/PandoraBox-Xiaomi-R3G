module("luci.controller.hwacc",package.seeall)
function index()
if not nixio.fs.access("/etc/config/hwacc")then
return
end
local e
e=entry({"admin","network","hwacc"},cbi("hwacc/hwacc"),_("Hardware Accelerate"))
e.dependent=true
end
