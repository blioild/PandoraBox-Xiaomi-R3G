module("luci.controller.minidlna",package.seeall)
function index()
if not nixio.fs.access("/etc/config/minidlna")then
return
end
local e
e=entry({"admin","services","minidlna"},cbi("minidlna"),_("miniDLNA"))
e.dependent=true
entry({"admin","services","minidlna_status"},call("minidlna_status"))
end
function minidlna_status()
local t=require"luci.sys"
local e=require"luci.model.uci".cursor()
local a=tonumber(e:get_first("minidlna","minidlna","port"))
local e={
running=(t.call("pidof minidlna >/dev/null")==0),
audio=0,
video=0,
image=0
}
if e.running then
local a=t.httpget("http://127.0.0.1:%d/"%(a or 8200),true)
if a then
local t=a:read("*a")
if t then
e.audio=(tonumber(t:match("Audio files</td><td>(%d+)"))or 0)
e.video=(tonumber(t:match("Video files</td><td>(%d+)"))or 0)
e.image=(tonumber(t:match("Image files</td><td>(%d+)"))or 0)
end
a:close()
end
end
luci.http.prepare_content("application/json")
luci.http.write_json(e)
end
