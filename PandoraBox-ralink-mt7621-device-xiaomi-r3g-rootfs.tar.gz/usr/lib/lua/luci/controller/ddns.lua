module("luci.controller.ddns",package.seeall)
local u=require"nixio"
local f=require"nixio.fs"
local n=require"luci.dispatcher"
local t=require"luci.http"
local e=require"luci.i18n"
local s=require"luci.model.ipkg"
local c=require"luci.sys"
local m=require"luci.model.uci"
local r=require"luci.util"
local o=require"luci.tools.ddns"
luci_helper="/usr/lib/ddns/dynamic_dns_lucihelper.sh"
local a="ddns-scripts"
local i="2.7.6"
local w=luci_helper..[[ -V | awk {'print $2'}]]
local d="luci-app-ddns"
local h="Dynamic DNS"
local l="2.4.8-2"
function index()
local e=require"nixio.fs"
local t=require"luci.sys"
local t=require"luci.tools.ddns"
local t=require"luci.model.uci"
if not e.access("/etc/config/ddns")then
e.writefile("/etc/config/ddns","")
end
local t=t.cursor()
local a=false
t:foreach("ddns","service",function(e)
if not e["lookup_host"]and e["domain"]then
t:set("ddns",e[".name"],"lookup_host",e["domain"])
a=true
end
end)
if a then t:commit("ddns")end
t:unload("ddns")
entry({"admin","services","ddns"},cbi("ddns/overview"),_("Dynamic DNS"),59)
entry({"admin","services","ddns","detail"},cbi("ddns/detail"),nil).leaf=true
entry({"admin","services","ddns","hints"},cbi("ddns/hints",
{hideapplybtn=true,hidesavebtn=true,hideresetbtn=true}),nil).leaf=true
entry({"admin","services","ddns","global"},cbi("ddns/global"),nil).leaf=true
entry({"admin","services","ddns","logview"},call("logread")).leaf=true
entry({"admin","services","ddns","startstop"},post("startstop")).leaf=true
entry({"admin","services","ddns","status"},call("status")).leaf=true
end
function app_description()
return e.translate("Dynamic DNS allows that your router can be reached with "..
"a fixed hostname while having a dynamically changing IP address.")
..[[<br />]]
..e.translate("OpenWrt Wiki")..": "
..[[<a href="http://wiki.openwrt.org/doc/howto/ddns.client" target="_blank">]]
..e.translate("DDNS Client Documentation")..[[</a>]]
.." --- "
..[[<a href="http://wiki.openwrt.org/doc/uci/ddns" target="_blank">]]
..e.translate("DDNS Client Configuration")..[[</a>]]
end
function app_title_back()
return[[<a href="]]
..n.build_url("admin","services","ddns")
..[[">]]
..e.translate(h)
..[[</a>]]
end
function app_title_main()
return[[<a href="javascript:alert(']]
..e.translate("Version Information")
..[[\n\n]]..d
..[[\n\t]]..e.translate("Version")..[[:\t]]..l
..[[\n\n]]..a..[[ ]]..e.translate("required")..[[:]]
..[[\n\t]]..e.translate("Version")..[[:\t]]
..i..[[ ]]..e.translate("or higher")
..[[\n\n]]..a..[[ ]]..e.translate("installed")..[[:]]
..[[\n\t]]..e.translate("Version")..[[:\t]]
..(service_version()or e.translate("NOT installed"))
..[[\n\n]]
..[[')">]]
..e.translate(h)
..[[</a>]]
end
function service_version()
local e=nil
e=r.exec(w)
if#e>0 then return e end
s.list_installed(a,function(a,t,a)
if t and(#t>0)then e=t end
end
)
return e
end
function service_ok()
return s.compare_versions((service_version()or"0"),">=",i)
end
local function l()
local u=m.cursor()
local e=c.init.enabled("ddns")and 1 or 0
local t=n.build_url("admin","system","startup")
local i={}
i[#i+1]={
enabled=e,
url_up=t,
}
u:foreach("ddns","service",function(e)
local r=e[".name"]
local d=tonumber(e["enabled"])or 0
local l="_empty_"
local a="_empty_"
local t=o.calc_seconds(
tonumber(e["force_interval"])or 72,
e["force_unit"]or"hours")
local h=o.get_pid(r)
local n=c.uptime()
local s=o.get_lastupd(r)
if s>n then
s=0
end
if s==0 then
l="_never_"
else
local e=os.time()-n+s
l=o.epoch2date(e)
a=o.epoch2date(e+t)
end
t=(t>n)and n or t
if h>0 and(s+t-n)<=0 then
a="_verify_"
elseif t==0 then
a="_runonce_"
elseif h==0 and d==0 then
a="_disabled_"
elseif h==0 and d~=0 then
a="_stopped_"
end
local t=e["interface"]or"wan"
local o=tonumber(e["use_ipv6"])or 0
local n=(o==1)and"IPv6"or"IPv4"
t=n.." / "..t
local n=e["lookup_host"]or"_nolookup_"
local s=e["dns_server"]or""
local f=tonumber(e["force_ipversion"]or 0)
local m=tonumber(e["force_dnstcp"]or 0)
local u=tonumber(e["is_glue"]or 0)
local e=luci_helper..[[ -]]
if(o==1)then e=e..[[6]]end
if(f==1)then e=e..[[f]]end
if(m==1)then e=e..[[t]]end
if(u==1)then e=e..[[g]]end
e=e..[[l ]]..n
if(#s>0)then e=e..[[ -d ]]..s end
e=e..[[ -- get_registered_ip]]
local e=c.exec(e)
if e==""then
e="_nodata_"
end
i[#i+1]={
section=r,
enabled=d,
iface=t,
lookup=n,
reg_ip=e,
pid=h,
datelast=l,
datenext=a
}
end)
u:unload("ddns")
return i
end
function logread(o)
local a=m.cursor()
local e=a:get("ddns","global","ddns_logdir")or"/var/log/ddns"
local e=e.."/"..o..".log"
local e=f.readfile(e)
if not e or#e==0 then
e="_nodata_"
end
a:unload("ddns")
t.write(e)
end
function startstop(i,n)
local e=m.cursor()
local o=o.get_pid(i)
local a={}
if o>0 then
local e=u.kill(o,15)
u.nanosleep(2)
a=l()
t.prepare_content("application/json")
t.write_json(a)
return
end
local o=true
local s=e:changes("ddns")
for e,t in pairs(s)do
if e~="ddns"then
o=false
break
end
for t,e in pairs(t)do
if t~=i then
o=false
break
end
for e,t in pairs(e)do
if e~="enabled"then
o=false
break
end
end
end
end
if not o then
t.write("_uncommitted_")
return
end
e:set("ddns",i,"enabled",((n=="true")and"1"or"0"))
e:save("ddns")
e:commit("ddns")
e:unload("ddns")
local e=luci_helper..[[ -S ]]..i..[[ -- start]]
os.execute(e)
u.nanosleep(3)
a=l()
t.prepare_content("application/json")
t.write_json(a)
end
function status()
local e=l()
t.prepare_content("application/json")
t.write_json(e)
end
